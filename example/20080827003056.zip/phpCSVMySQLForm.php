<html>
<head>
<title>ThaiCreate.Com PHP & CSV To MySQL</title>
</head>
<body>
<form action="phpCSVMySQLUpload.php" method="post" enctype="multipart/form-data" name="form1">
  <input name="fileCSV" type="file" id="fileCSV">
  <input name="btnSubmit" type="submit" id="btnSubmit" value="Submit">
</form>
</body>
</html>

